﻿Imports System.IO
Module DVDInfo

    Function DVDInfo()
        ''temp no usage

        Return True
    End Function


    Function readX(ByVal file As String, ByVal offset As UInt64, ByVal count As UInt64) As Byte()
        'hon Code 2023 (FUNCT v1.2.40)

        Dim buffer() As Byte = New Byte(count - 1) {}
        Using fs As New FileStream(file, FileMode.Open, FileAccess.Read, FileShare.Read)
            fs.Seek(offset, SeekOrigin.Begin)
            fs.Read(buffer, 0, count)
        End Using
        Return buffer
    End Function

    Function GetDirectorySize(ByVal path As String) As Long
        Dim files = Directory.GetFiles(path, "*.*")

        Dim totalBytes As UInt64 = 0
        For Each name As String In files
            Dim info = New FileInfo(name)
            totalBytes += info.Length
        Next

        Return totalBytes
    End Function

    Function MediaInfo(ByVal command As String) As String
        Dim p As Process = New Process()
        Dim pi As ProcessStartInfo = New ProcessStartInfo()
        pi.Arguments = command
        pi.FileName = "MediaInfo.exe"
        pi.UseShellExecute = False
        pi.RedirectStandardOutput = True
        p.StartInfo = pi
        p.Start()

        Dim ret As String
        Using oStreamReader As System.IO.StreamReader = p.StandardOutput
            ret = oStreamReader.ReadToEnd()
        End Using
        ret = ret.Substring(0, ret.Length - 1)
        Return ret
    End Function

    Function FNDBigger(ByVal path As String)
        Dim files = Directory.GetFiles(path, "VTS_*.VOB", IO.SearchOption.TopDirectoryOnly)
        Dim bigsize As UInt64 = 0
        Dim bigname As String = ""
        For Each name As String In files
            Dim info = New FileInfo(name)
            If info.Length > bigsize Then
                bigsize = info.Length
                bigname = name
            End If
        Next
        Return bigname
    End Function
End Module
