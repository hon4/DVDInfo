﻿Imports System.IO
Public Class Open

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        If Not String.IsNullOrEmpty(TextBox1.Text) Then
            Form1.Label2.Text = Path.GetDirectoryName(TextBox1.Text)
            Generator.ShowDialog()
            Me.Hide()
        Else
            MsgBox("No VIDEO_TS.IFO selected.")
        End If
    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        OpenFileDialog.ShowDialog()
        If Not String.IsNullOrEmpty(OpenFileDialog.FileName) Then
            TextBox1.Text = OpenFileDialog.FileName
        End If
    End Sub

    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click
        Me.Dispose()
    End Sub

    Private Sub Open_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        FolderRadio.TabStop = False
    End Sub
End Class