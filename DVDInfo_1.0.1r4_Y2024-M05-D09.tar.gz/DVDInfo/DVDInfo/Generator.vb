﻿Imports System.IO
Public Class Generator

    Private Sub Generator_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Dim DVDPath As String = Form1.Label2.Text

        Dim ret As String = "DVD INFO"
        Dim fle = My.Computer.FileSystem.ReadAllText(Open.TextBox1.Text)
        ret &= vbNewLine + "Disk Title: " + System.Text.Encoding.Default.GetString(readX(Open.TextBox1.Text, 64, fle.Substring(64).IndexOf(vbNullChar)))
        ret &= vbNewLine + "Disk Size: " + GetDirectorySize(DVDPath).ToString("N0") + " bytes"
        ret &= vbNewLine + "DVDInfo: " + My.Application.Info.Version.ToString
        ret &= vbNewLine
        
        Dim bigname As String = FNDBigger(DVDPath)

        Dim files = Directory.GetFiles(DVDPath, Path.GetFileName(bigname).Substring(0, 7) + "*.VOB", IO.SearchOption.TopDirectoryOnly)
        Dim filesn As List(Of String) = New List(Of String)
        Dim mvsize As UInt64 = 0
        For Each name As String In files
            If Not Path.GetFileName(name) = Path.GetFileName(bigname).Substring(0, 7) + "0.VOB" Then
                filesn.Add(Path.GetFileName(name))
                Dim info = New FileInfo(name)
                mvsize += info.Length
            End If
        Next
        Dim movFilesStr As String = Join(filesn.ToArray, ", ")

        Dim metafile As String = Path.GetFileName(bigname).Substring(0, 7) + "0.IFO"
        If Not File.Exists(DVDPath + Path.DirectorySeparatorChar + metafile) Then
            MsgBox(metafile + " Not found." + vbNewLine + "Cannot find MetaData.")
        End If

        ret &= vbNewLine + "MOVIE"
        ret &= vbNewLine + "Parts: " + (files.Length - 1).ToString
        ret &= vbNewLine + "Video Files: " + movFilesStr
        ret &= vbNewLine + "MetaFile: " + metafile
        ret &= vbNewLine + "Movie Size: " + mvsize.ToString("N0") + " bytes"

        Dim ifoaudiocmd As String = "Audio;%Format%|%Language/String%|%Channel(s)%|%SamplingRate/String%*"
        Dim ifometa As String = MediaInfo(" --Output=""Video;%Duration/String3%,%Format%,%Format_Version%,%Height%,%FrameRate%,%DisplayAspectRatio/String%,%Standard%," + vbNewLine + ifoaudiocmd + """ """ + DVDPath + "\" + metafile + """")
        Dim ifometalst As String() = ifometa.Split(",")
        ifometalst(1) = ifometalst(1).Replace(" Video", "")
        ifometalst(2) = ifometalst(2).Replace("Version ", "")
        ifometalst(7) = ifometalst(7).Substring(0, ifometalst(7).Length - 1)

        Dim vobmeta As String = MediaInfo(" --Output=""Video;%Format_Profile%"" """ + DVDPath + "\" + (filesn.ToArray)(0) + """")
        Dim vobmetalst As String() = vobmeta.Split(",")
        vobmetalst(0) = vobmetalst(0).Substring(0, vobmetalst(0).IndexOf("@"))

        Dim vobaudiocmd As String = "Audio;%BitRate/String%*"
        Dim BitRateSUM As UInteger = 0
        For Each Name As String In filesn
            Dim temp As String = MediaInfo(" --Output=""Video;%BitRate%"" """ + DVDPath + "\" + Name + """")
            BitRateSUM += CDbl(Val(temp)) / 1000
        Next
        Dim AVGBitRate As Integer = CInt(BitRateSUM / filesn.ToArray.Length)

        ret &= vbNewLine + "Length: " + ifometalst(0) + " (h:m:s.ms)"
        ret &= vbNewLine + "Standard: " + ifometalst(6)

        'Video Start
        ret &= vbNewLine

        Dim avg As String = ""
        Dim avgfill As String = ""
        If filesn.ToArray.Length > 1 Then
            avg = "(avg)"
            avgfill = "     "
        End If

        ret &= vbNewLine + "VIDEO"
        ret &= vbNewLine + "Codec    BitRate" + avgfill + "     Description"
        ret &= vbNewLine + "-----    -------" + avgfill + "     -----------"
        ret &= vbNewLine + ifometalst(1) + "-" + ifometalst(2) + "   " + AVGBitRate.ToString + " kbps " + avg + "  " + ifometalst(3) + "p / " + ifometalst(4) + " FPS / " + ifometalst(5) + " / " + vobmetalst(0) + " Profile"
        'Video End

        'Audio Start
        Dim audbitr As String = MediaInfo(" --Output=""Audio;%BitRate/String%,"" """ + DVDPath + "\" + (filesn.ToArray)(0) + """")
        If Not String.IsNullOrWhiteSpace(audbitr) Then
            Dim audbitrA As String() = audbitr.Substring(0, audbitr.Length - 2).Split(",")

            ret &= vbNewLine

            ret &= vbNewLine + "AUDIO"
            ret &= vbNewLine + "Codec    Language    Bitrate    Description"
            ret &= vbNewLine + "-----    --------    -------    -----------"
            Dim ifoaudlstS As String() = ifometalst(7).Split("*")
            Dim ifoaudlstL As List(Of String) = New List(Of String)
            For Each audtmpS As String In ifoaudlstS
                ifoaudlstL.Add(audtmpS)
            Next

            Dim i As Integer = 0
            Dim audbitrAlen As Integer = audbitrA.Length
            For Each audtmp As String In ifoaudlstL
                Dim audtmpA As String() = audtmp.Split("|").ToArray
                If audtmpA.Length > 1 Then
                    If audtmpA(2) = 6 Then
                        audtmpA(2) = "5.1"
                    End If
                    Dim xtra As String = ""
                    If audtmpA(0) = "AC-3" Then
                        xtra = "Dolby Digital"
                    End If
                    Dim bitr As String = "-"
                    If audbitrAlen > i Then
                        bitr = audbitrA(i).Replace("kb/s", "kbps")
                    End If
                    ret &= vbNewLine + audtmpA(0).PadRight(9, " "c) + audtmpA(1).PadRight(12, " "c) + bitr.PadRight(11, " "c) + Decimal.Parse(audtmpA(2)).ToString("F1") + " / " + audtmpA(3) + " / " + xtra
                End If
                i += 1
            Next
        End If
        'Audio End

        'Subtitles Start
        Dim substext As String = MediaInfo(" --Output=""Text;%Format%,%Language/String%|"" """ + DVDPath + "\" + metafile + """")
        If Not String.IsNullOrWhiteSpace(substext) Then
            substext = substext.Substring(0, substext.Length - 2)
            ret &= vbNewLine
            ret &= vbNewLine + "SUBTITLES"
            ret &= vbNewLine + "Codec    Language"
            ret &= vbNewLine + "-----    --------"
            Dim subtxtA As String() = substext.Split("|")
            For Each stA As String In subtxtA
                Dim substA As String() = stA.Split(",")
                ret &= vbNewLine + substA(0).PadRight(9, " "c) + substA(1)
            Next
        End If
        'Subtitles End

        Form1.TextBox1.Text = ret

        Me.Dispose()
    End Sub
End Class
