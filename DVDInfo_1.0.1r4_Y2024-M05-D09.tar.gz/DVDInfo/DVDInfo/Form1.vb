﻿Public Class Form1

    Private Sub OpenToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles OpenToolStripMenuItem.Click
        Open.ShowDialog()
    End Sub

    Private Sub ExitToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ExitToolStripMenuItem.Click
        End
    End Sub

    Private Sub AboutToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles AboutToolStripMenuItem.Click
        About.ShowDialog()
    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        Clipboard.SetText(TextBox1.Text)
    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        SaveFileDialog1.ShowDialog()
        If Not String.IsNullOrEmpty(SaveFileDialog1.FileName) Then
            If Not IO.File.Exists(SaveFileDialog1.FileName) Then
                IO.File.Create(SaveFileDialog1.FileName)
            End If
            Dim objWriter As New IO.StreamWriter(SaveFileDialog1.FileName, False)
            objWriter.Write(TextBox1.Text)
            objWriter.Close()
        End If
    End Sub

    Private Sub TextBox1_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TextBox1.TextChanged
        If Not String.IsNullOrWhiteSpace(TextBox1.Text) Then
            Button1.Enabled = True
            Button2.Enabled = True
        End If
    End Sub
End Class
